README

=========================================
CloudENTmvc.zip
=========================================
1. Open Eclipse and select "File" > "Import" from the menu.

2. In the "Import" dialog, expand the "General" folder and select "Existing Projects into Workspace."

3. Click "Next" and browse to the directory where you have cloned or downloaded the RESTful API, MVCassignment and My-First-Project projects.

4. Select the project and click "Finish" to import it into Eclipse.

5. For the MVCassignemnt project locate the bookController.java in the Controller file and run on server. Also locate the View.jsp, Home.jsp, and Update.jsp found in the 'webapp' file. For the RESTful API project, please run the BookRestfulAPI.java and the RESTful API folder on the server. For the 'My-First-Project' project, please run on App Engine. 
6. Other files included is the word file 'Critical Analysis 22493230'.