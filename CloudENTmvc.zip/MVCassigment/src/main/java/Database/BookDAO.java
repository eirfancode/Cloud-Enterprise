package Database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;

import Models.Book;

public class BookDAO {

    Book oneBook = null;
    Connection conn = null;
    Statement stmt = null;
    String user = "irfaneim";
    String password = "houtweRn7";
    // Note none default port used, 6306 not 3306
    String url = "jdbc:mysql://mudfoot.doc.stu.mmu.ac.uk:6306/" + user;

    public BookDAO() {}

    private void openConnection() {
        // loading jdbc driver for mysql
        try {
            Class.forName("com.mysql.jdbc.Driver").getDeclaredConstructor().newInstance();
        } catch (Exception e) {
            System.out.println(e);
        }

        // connecting to the database
        try {
            // connection string for the demos database, username demos, password demos
            conn = DriverManager.getConnection(url, user, password);
            stmt = conn.createStatement();
        } catch (SQLException se) {
            System.out.println(se);
        }
    }

    private void closeConnection() {
        try {
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private Book getNextBook(ResultSet rs) {
        Book thisBook = null;
        try {
            thisBook = new Book(
                    rs.getInt("id"),
                    rs.getString("title"),
                    rs.getString("author"),
                    rs.getString("date"),
                    rs.getString("genres"),
                    rs.getString("characters"),
                    rs.getString("synopsis"));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return thisBook;
    }

    public ArrayList<Book> getAllBooks() {
        ArrayList<Book> allBooks = new ArrayList<Book>();
        openConnection();

        // Create select statement and execute it
        try {
            String selectSQL = "SELECT * FROM books";
            ResultSet rs1 = stmt.executeQuery(selectSQL);
            // Retrieve the results
            while (rs1.next()) {
                oneBook = getNextBook(rs1);
                allBooks.add(oneBook);
            }

            rs1.close();
            stmt.close();
            closeConnection();
        } catch (SQLException se) {
            System.out.println(se);
        }

        return allBooks;
    }

    public Book getBookByID(int id) {
        openConnection();
        oneBook = null;

        // Create select statement and execute it
        try {
            String selectSQL = "SELECT * FROM books WHERE id=?";
            PreparedStatement pstmt = conn.prepareStatement(selectSQL);
            pstmt.setInt(1, id);
            ResultSet rs1 = pstmt.executeQuery();

            // Retrieve the results
            if (rs1.next()) {
                oneBook = getNextBook(rs1);
            }

            rs1.close();
            pstmt.close();
            closeConnection();
        } catch (SQLException se) {
            System.out.println(se);
        }

        return oneBook;
    }

    public Collection<Book> searchBook(String searchStr) {
        ArrayList<Book> books = new ArrayList<Book>();
        openConnection();

        try {
            String searchSQL = "SELECT * FROM books WHERE title LIKE ? OR author LIKE ?";
            PreparedStatement pstmt = conn.prepareStatement(searchSQL);
            pstmt.setString(1, "%" + searchStr + "%");
            pstmt.setString(2, "%" + searchStr + "%");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Book b = getNextBook(rs);
                books.add(b);
            }

            rs.close();
            pstmt.close();
        } catch (SQLException se) {
            System.out.println(se);
        } finally {
            closeConnection();
        }

        return books;
    }

    public void deleteBook(int id) {
        openConnection();

        try {
            String deleteSQL = "DELETE FROM books WHERE id = ?";
            PreparedStatement pstmt = conn.prepareStatement(deleteSQL);
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            pstmt.close();
        } catch (SQLException se) {
            System.out.println(se);
        } finally {
            closeConnection();
        }
    }

    public void updateBook(Book b) {
        openConnection();

        try {
            String updateSQL = "UPDATE books SET title = ?, author = ?, date = ?, genres = ?, characters = ?, synopsis = ? WHERE id = ?";
            PreparedStatement pstmt = conn.prepareStatement(updateSQL);
            pstmt.setString(1, b.getTitle());
            pstmt.setString(2, b.getAuthor());
            pstmt.setString(3, b.getDate());
            pstmt.setString(4, b.getGenres());
            pstmt.setString(5, b.getCharacters());
            pstmt.setString(6, b.getSynopsis());
            pstmt.setInt(7, b.getId());
            pstmt.executeUpdate();
            pstmt.close();
        } catch (SQLException se) {
            System.out.println(se);
        } finally {
            closeConnection();
        }
    }

    public void insertBook(Book b) {
        openConnection();

        try {
            String insertSQL = "INSERT INTO books (title, author, date, genres, characters, synopsis) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(insertSQL);
            pstmt.setString(1, b.getTitle());
            pstmt.setString(2, b.getAuthor());
            pstmt.setString(3, b.getDate());
            pstmt.setString(4, b.getGenres());
            pstmt.setString(5, b.getCharacters());
            pstmt.setString(6, b.getSynopsis());
            pstmt.executeUpdate();
            pstmt.close();
        } catch (SQLException se) {
            System.out.println(se);
        } finally {
            closeConnection();
        }
    }
}
