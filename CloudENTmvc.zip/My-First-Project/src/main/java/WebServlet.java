
public @interface WebServlet {

	String name();

	String[] urlPatterns();

}
