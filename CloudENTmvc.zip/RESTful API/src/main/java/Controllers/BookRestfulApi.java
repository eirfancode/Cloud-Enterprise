package Controllers;

import com.google.gson.Gson;
//import javax.json.Json;
//import javax.json.JsonArray;
//import javax.json.JsonObject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Database.BookDAO;
import Models.Book;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

@WebServlet(urlPatterns = {"/RESTful_API"}, name = "BookRestfulApi", loadOnStartup = 1)
public class BookRestfulApi extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        BookDAO dao = new BookDAO();
        ArrayList<Book> allBooks = dao.getAllBooks();

        Gson gson = new Gson();
        String json = gson.toJson(allBooks);

        out.print(json);
        out.close();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve and handle the data sent in the POST request
        String title = request.getParameter("title");
        String author = request.getParameter("author");
        // ... other parameters

        // Create a new Book object
        Book book = new Book();
        book.setTitle(title);
        book.setAuthor(author);
        

        // Insert the book into the database
        BookDAO dao = new BookDAO();
        dao.insertBook(book);

        response.setContentType("text/plain");
        PrintWriter out = response.getWriter();
        out.write("Book inserted");
        out.close();
    }

}

