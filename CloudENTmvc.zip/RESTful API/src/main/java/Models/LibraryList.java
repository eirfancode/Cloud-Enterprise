package Models;
import java.util.List;
import org.apache.tomcat.jni.Library;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "libraries")
public class LibraryList {
@XmlElement(name = "library")
private List<Library> librariesList;
public LibraryList() {
}
public LibraryList(List<Library> librariesList) {
this.librariesList = librariesList;
}
public List<Library> getLibrariesList() {
return librariesList;
}
public void setLibrariesList(List<Library> librariesList) {
this.librariesList = librariesList;
}
}
