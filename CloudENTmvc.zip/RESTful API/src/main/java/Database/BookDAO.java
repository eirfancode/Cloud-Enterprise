package Database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import Models.Book;

public class BookDAO {
    private Connection conn;
    private String url = "jdbc:mysql://mudfoot.doc.stu.mmu.ac.uk:6306/"; 
    private String username = "irfaneim"; 
    private String password = "houtweRn7";

    public BookDAO() {
        openConnection();
    }

    private void openConnection() {
        try {
            conn = DriverManager.getConnection(url, username, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void closeConnection() {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Book> getAllBooks() {
        ArrayList<Book> books = new ArrayList<>();

        try {
            String selectSQL = "SELECT * FROM books";
            PreparedStatement pstmt = conn.prepareStatement(selectSQL);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("id");
                String title = rs.getString("title");
                String author = rs.getString("author");
                String date = rs.getString("date");
                String genres = rs.getString("genres");
                String characters = rs.getString("characters");
                String synopsis = rs.getString("synopsis");

                Book book = new Book(id, title, author, date, genres, characters, synopsis);
                books.add(book);
            }

            rs.close();
            pstmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeConnection();
        }

        return books;
    }

    public void insertBook(Book b) {
        openConnection();

        try {
            String insertSQL = "INSERT INTO books (title, author, date, genres, characters, synopsis) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(insertSQL);
            pstmt.setString(1, b.getTitle());
            pstmt.setString(2, b.getAuthor());
            pstmt.setString(3, b.getDate());
            pstmt.setString(4, b.getGenres());
            pstmt.setString(5, b.getCharacters());
            pstmt.setString(6, b.getSynopsis());
            pstmt.executeUpdate();
            pstmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeConnection();
        }
    }
}