// CRUD Functionality for Books

// Create a new book
function createBook() {
  var title = getValue("title");
  var author = getValue("author");
  // ... other book properties

  var data = "title=" + title + "&author=" + author;
  // ... append other book properties to the data string

  ajaxPost("create-book", data, function(response) {
    alert(response); // Display success message
    clearForm(); // Clear the form after creating the book
  });
}

// Read a book by ID
function readBookById() {
  var bookId = getValue("id");

  ajaxGet("find-book-by-id?bookId=" + bookId, function(response) {
    document.getElementById("resultRegion").innerHTML = response;
  });
}

// Update a book by ID
function updateBook() {
  var bookId = getValue("id");
  var title = getValue("title");
  var author = getValue("author");
  // ... other book properties

  var data = "bookId=" + bookId + "&title=" + title + "&author=" + author;
  // ... append other book properties to the data string

  ajaxPost("update-book", data, function(response) {
    alert(response); // Display success message
    clearForm(); // Clear the form after updating the book
  });
}

// Delete a book by ID
function deleteBook() {
  var bookId = getValue("id");

  ajaxGet("delete-book?bookId=" + bookId, function(response) {
    alert(response); // Display success message
    clearForm(); // Clear the form after deleting the book
  });
}

// Clear the book form
function clearForm() {
  document.getElementById("bookForm").reset();
}

// Helper function to make an HTTP POST request
function ajaxPost(url, data, callback) {
  var request = getRequestObject();
  request.onreadystatechange = function() {
    if (request.readyState === 4 && request.status === 200) {
      callback(request.responseText);
    }
  };
  request.open("POST", url, true);
  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  request.send(data);
}

// Helper function to make an HTTP GET request
function ajaxGet(url, callback) {
  var request = getRequestObject();
  request.onreadystatechange = function() {
    if (request.readyState === 4 && request.status === 200) {
      callback(request.responseText);
    }
  };
  request.open("GET", url, true);
  request.send();
}

// Helper function to get the value of an input element by ID
function getValue(id) {
  return encodeURIComponent(document.getElementById(id).value);
}
